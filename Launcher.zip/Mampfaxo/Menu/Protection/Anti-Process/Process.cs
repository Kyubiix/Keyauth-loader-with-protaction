﻿using System;
using System.Diagnostics;
using System.Threading;
using System.Windows;

namespace Protection
{
    internal class ProcessCheck
    {
        public static void Initialize()
        {
            Thread procThread = new Thread(check);
            procThread.Start();
        }
        public static void check()
        {
            if (IsSandboxie())
                msg();
            if (IsDebugger())
                msg();
        }


        internal static bool IsSandboxie()
        {
            return IsDetected();
        }

        internal static bool IsDebugger()
        {
            return Run();
        }


        internal static void msg()
        {
            MessageBox.Show("Detected Malicious Application!", "Mampfaxo");
            Environment.Exit(0);
        }


        private static IntPtr GetModuleHandle(string libName)
        {
            foreach (ProcessModule pMod in Process.GetCurrentProcess().Modules)
                if (pMod.ModuleName.ToLower().Contains(libName.ToLower()))
                    return pMod.BaseAddress;
            return IntPtr.Zero;
        }

        internal static bool IsDetected()
        {
            return GetModuleHandle("SbieDll.dll") != IntPtr.Zero;
        }

        internal static bool Run()
        {
            var returnvalue = false;
            if (Debugger.IsAttached || Debugger.IsLogging())
            {
            }
            else
            {
                //var strArray = new string[41] { "dnspy", "codecracker", "x32dbg", "x64dbg", "ollydbg", "ida", "charles", "simpleassembly", "peek", "httpanalyzer", "httpdebug", "fiddler", "wireshark", "dbx", "mdbg", "gdb", "windbg", "dbgclr", "kdb", "kgdb", "mdb", "processhacker", "scylla_x86", "scylla_x64", "scylla", "idau64", "idau", "idaq", "idaq64", "idaw", "idaw64", "idag", "idag64", "ida64", "ida", "ImportREC", "IMMUNITYDEBUGGER", "MegaDumper", "CodeBrowser", "reshacker", "cheat engine" };
                //foreach (var process in Process.GetProcesses())
                //    if (process != Process.GetCurrentProcess())
                //        for (var index = 0; index < strArray.Length; ++index)
                //        {
                //            if (process.ProcessName.ToLower().Contains(strArray[index])) returnvalue = true;
                //            if (process.MainWindowTitle.ToLower().Contains(strArray[index])) returnvalue = true;
                //        }
            }
            return returnvalue;
        }
    }
}