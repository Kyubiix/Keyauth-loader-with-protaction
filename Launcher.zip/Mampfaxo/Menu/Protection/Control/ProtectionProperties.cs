﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mampfaxo.Menu.Protection.Control
{
    internal class ProtectionProperties
    {
        public bool AntiDebug { get; set; }
        public bool AntiDump { get; set; }
        public bool AntiProcess { get; set; }
    }
}
