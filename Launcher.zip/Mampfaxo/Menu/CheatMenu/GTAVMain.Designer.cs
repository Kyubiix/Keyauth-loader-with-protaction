﻿namespace Mampfaxo
{
    partial class GTAVMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GTAVMain));
            this.SidePanel = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.AccountPanel = new System.Windows.Forms.Panel();
            this.ExpiryLabel = new System.Windows.Forms.Label();
            this.TillLabel = new System.Windows.Forms.Label();
            this.NameLabel = new System.Windows.Forms.Label();
            this.ProfilePicture = new Mampfaxo.ProfilePicture();
            this.newsBtn = new FontAwesome.Sharp.IconButton();
            this.label1 = new System.Windows.Forms.Label();
            this.injectBtn = new FontAwesome.Sharp.IconButton();
            this.logoLabel = new System.Windows.Forms.Label();
            this.AboutPanel = new System.Windows.Forms.Panel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.iconButton9 = new FontAwesome.Sharp.IconButton();
            this.SearchButton = new FontAwesome.Sharp.IconButton();
            this.AboutButton = new FontAwesome.Sharp.IconButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SubPanel = new System.Windows.Forms.Panel();
            this.SidePanel.SuspendLayout();
            this.AccountPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ProfilePicture)).BeginInit();
            this.AboutPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // SidePanel
            // 
            resources.ApplyResources(this.SidePanel, "SidePanel");
            this.SidePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(19)))), ((int)(((byte)(18)))));
            this.SidePanel.Controls.Add(this.panel2);
            this.SidePanel.Controls.Add(this.AccountPanel);
            this.SidePanel.Controls.Add(this.newsBtn);
            this.SidePanel.Controls.Add(this.label1);
            this.SidePanel.Controls.Add(this.injectBtn);
            this.SidePanel.Controls.Add(this.logoLabel);
            this.SidePanel.Name = "SidePanel";
            // 
            // panel2
            // 
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.panel2.Name = "panel2";
            // 
            // AccountPanel
            // 
            resources.ApplyResources(this.AccountPanel, "AccountPanel");
            this.AccountPanel.Controls.Add(this.ExpiryLabel);
            this.AccountPanel.Controls.Add(this.TillLabel);
            this.AccountPanel.Controls.Add(this.NameLabel);
            this.AccountPanel.Controls.Add(this.ProfilePicture);
            this.AccountPanel.Name = "AccountPanel";
            // 
            // ExpiryLabel
            // 
            resources.ApplyResources(this.ExpiryLabel, "ExpiryLabel");
            this.ExpiryLabel.ForeColor = System.Drawing.Color.White;
            this.ExpiryLabel.Name = "ExpiryLabel";
            // 
            // TillLabel
            // 
            resources.ApplyResources(this.TillLabel, "TillLabel");
            this.TillLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(83)))), ((int)(((byte)(82)))));
            this.TillLabel.Name = "TillLabel";
            // 
            // NameLabel
            // 
            resources.ApplyResources(this.NameLabel, "NameLabel");
            this.NameLabel.ForeColor = System.Drawing.Color.White;
            this.NameLabel.Name = "NameLabel";
            // 
            // ProfilePicture
            // 
            resources.ApplyResources(this.ProfilePicture, "ProfilePicture");
            this.ProfilePicture.Name = "ProfilePicture";
            this.ProfilePicture.TabStop = false;
            // 
            // newsBtn
            // 
            resources.ApplyResources(this.newsBtn, "newsBtn");
            this.newsBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(19)))), ((int)(((byte)(18)))));
            this.newsBtn.FlatAppearance.BorderSize = 0;
            this.newsBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(226)))), ((int)(((byte)(228)))));
            this.newsBtn.IconChar = FontAwesome.Sharp.IconChar.Scroll;
            this.newsBtn.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(159)))), ((int)(((byte)(221)))));
            this.newsBtn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.newsBtn.IconSize = 25;
            this.newsBtn.Name = "newsBtn";
            this.newsBtn.UseVisualStyleBackColor = false;
            this.newsBtn.Click += new System.EventHandler(this.newsBtn_Click);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(54)))), ((int)(((byte)(57)))));
            this.label1.Name = "label1";
            // 
            // injectBtn
            // 
            resources.ApplyResources(this.injectBtn, "injectBtn");
            this.injectBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(19)))), ((int)(((byte)(18)))));
            this.injectBtn.FlatAppearance.BorderSize = 0;
            this.injectBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(226)))), ((int)(((byte)(228)))));
            this.injectBtn.IconChar = FontAwesome.Sharp.IconChar.Code;
            this.injectBtn.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(159)))), ((int)(((byte)(221)))));
            this.injectBtn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.injectBtn.IconSize = 25;
            this.injectBtn.Name = "injectBtn";
            this.injectBtn.UseVisualStyleBackColor = false;
            this.injectBtn.Click += new System.EventHandler(this.injectBtn_Click);
            // 
            // logoLabel
            // 
            resources.ApplyResources(this.logoLabel, "logoLabel");
            this.logoLabel.ForeColor = System.Drawing.Color.White;
            this.logoLabel.Name = "logoLabel";
            // 
            // AboutPanel
            // 
            resources.ApplyResources(this.AboutPanel, "AboutPanel");
            this.AboutPanel.Controls.Add(this.comboBox1);
            this.AboutPanel.Controls.Add(this.iconButton9);
            this.AboutPanel.Controls.Add(this.SearchButton);
            this.AboutPanel.Controls.Add(this.AboutButton);
            this.AboutPanel.Name = "AboutPanel";
            this.AboutPanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.AboutPanel_MouseDown);
            this.AboutPanel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.AboutPanel_MouseMove);
            this.AboutPanel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.AboutPanel_MouseUp);
            // 
            // comboBox1
            // 
            resources.ApplyResources(this.comboBox1, "comboBox1");
            this.comboBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(8)))), ((int)(((byte)(13)))));
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.ForeColor = System.Drawing.Color.White;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            resources.GetString("comboBox1.Items"),
            resources.GetString("comboBox1.Items1"),
            resources.GetString("comboBox1.Items2")});
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // iconButton9
            // 
            resources.ApplyResources(this.iconButton9, "iconButton9");
            this.iconButton9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(8)))), ((int)(((byte)(13)))));
            this.iconButton9.FlatAppearance.BorderSize = 0;
            this.iconButton9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(226)))), ((int)(((byte)(228)))));
            this.iconButton9.IconChar = FontAwesome.Sharp.IconChar.SignOutAlt;
            this.iconButton9.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(159)))), ((int)(((byte)(221)))));
            this.iconButton9.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton9.IconSize = 25;
            this.iconButton9.Name = "iconButton9";
            this.iconButton9.UseVisualStyleBackColor = false;
            this.iconButton9.Click += new System.EventHandler(this.iconButton9_Click);
            // 
            // SearchButton
            // 
            resources.ApplyResources(this.SearchButton, "SearchButton");
            this.SearchButton.FlatAppearance.BorderSize = 0;
            this.SearchButton.ForeColor = System.Drawing.Color.White;
            this.SearchButton.IconChar = FontAwesome.Sharp.IconChar.Search;
            this.SearchButton.IconColor = System.Drawing.Color.White;
            this.SearchButton.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.SearchButton.IconSize = 17;
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.UseVisualStyleBackColor = true;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // AboutButton
            // 
            resources.ApplyResources(this.AboutButton, "AboutButton");
            this.AboutButton.FlatAppearance.BorderSize = 0;
            this.AboutButton.ForeColor = System.Drawing.Color.White;
            this.AboutButton.IconChar = FontAwesome.Sharp.IconChar.Cog;
            this.AboutButton.IconColor = System.Drawing.Color.White;
            this.AboutButton.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.AboutButton.IconSize = 17;
            this.AboutButton.Name = "AboutButton";
            this.AboutButton.UseVisualStyleBackColor = true;
            this.AboutButton.Click += new System.EventHandler(this.AboutButton_Click);
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(18)))), ((int)(((byte)(19)))));
            this.panel1.Name = "panel1";
            // 
            // SubPanel
            // 
            resources.ApplyResources(this.SubPanel, "SubPanel");
            this.SubPanel.Name = "SubPanel";
            this.SubPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.SubPanel_Paint);
            // 
            // GTAVMain
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(8)))), ((int)(((byte)(13)))));
            this.Controls.Add(this.SubPanel);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.AboutPanel);
            this.Controls.Add(this.SidePanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "GTAVMain";
            this.Opacity = 0.95D;
            this.Load += new System.EventHandler(this.GTAVMain_Load);
            this.SidePanel.ResumeLayout(false);
            this.SidePanel.PerformLayout();
            this.AccountPanel.ResumeLayout(false);
            this.AccountPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ProfilePicture)).EndInit();
            this.AboutPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel SidePanel;
        private System.Windows.Forms.Panel AboutPanel;
        private System.Windows.Forms.Label logoLabel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel SubPanel;
        private FontAwesome.Sharp.IconButton injectBtn;
        private FontAwesome.Sharp.IconButton newsBtn;
        private System.Windows.Forms.Label label1;
        private FontAwesome.Sharp.IconButton SearchButton;
        private FontAwesome.Sharp.IconButton AboutButton;
        private System.Windows.Forms.Panel AccountPanel;
        private System.Windows.Forms.Panel panel2;
        private ProfilePicture ProfilePicture;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label TillLabel;
        private System.Windows.Forms.Label ExpiryLabel;
        private FontAwesome.Sharp.IconButton iconButton9;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}