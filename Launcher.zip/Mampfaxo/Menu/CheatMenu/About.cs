﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using Mampfaxo.Menu.Protection.Control;

namespace Mampfaxo
{
    public partial class About : Form
    {
        static ProtectionProperties protection = new ProtectionProperties();

        //mov (Move Form)
        int mov;
        int movX;
        int movY;
        public About()
        {
            InitializeComponent();
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void UpperPanel_MouseMove(object sender, MouseEventArgs e)
        {
            if(mov == 1)
            {
                this.SetDesktopLocation(MousePosition.X - movX, MousePosition.Y - movY);
            }
        }

        private void UpperPanel_MouseUp(object sender, MouseEventArgs e)
        {
            mov = 0;
        }

        private void UpperPanel_MouseDown(object sender, MouseEventArgs e)
        {
            mov = 1;
            movX = e.X;
            movY = e.Y;
        }

        private void YTNinkjeboibtn_Click(object sender, EventArgs e)
        {
            Process.Start("https://www.youtube.com/channel/UCl0Pf09waKeAmRIZz6a-Mtg");
        }

        private void About_Load(object sender, EventArgs e)
        {


            protection.AntiDebug = true;
            protection.AntiDump = true;
            protection.AntiProcess = true;

            if (protection.AntiDebug)
            {
                Protection.Debug.Initialize();
                Console.WriteLine("[#] AntiDebug Has Been Initialized.");
            }
            else { }
            //
            if (protection.AntiDump)
            {
                Protection.Dump.Initialize();
                Console.WriteLine("[#] AntiDump Has Been Initialized.");
            }
            else { }
            //
            if (protection.AntiProcess)
            {
                Protection.ProcessCheck.Initialize();
                Console.WriteLine("[#] AntiProcess Has Been Initialized.");
            }
            else
            {

            }

            lblExpDate.Text = "" + UnixTimeToDateTime(long.Parse(Login.KeyAuthApp.user_data.subscriptions[0].expiry));
        }
        public DateTime UnixTimeToDateTime(long unixtime)
        {
            System.DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Local);
            dtDateTime = dtDateTime.AddSeconds(unixtime).ToLocalTime();
            return dtDateTime;
        }
    }
}
