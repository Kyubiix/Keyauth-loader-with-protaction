﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;
using System.Configuration;
using Mampfaxo.Menu.Classes;
using Mampfaxo.Menu.Protection.Control;

namespace Mampfaxo
{
    public partial class GTAVMain : Form
    {
        static ProtectionProperties protection = new ProtectionProperties();

        int mov;
        int movX;
        int movY;

        public GTAVMain()
        {
            InitializeComponent();
        }

        //OpenChildForm
        private Form activeForm = null;
        private void openChildForm(Form childForm)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            SubPanel.Controls.Add(childForm);
            SubPanel.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        private void injectBtn_Click(object sender, EventArgs e)
        {
            openChildForm(new InjectForm());
        }

        private void newsBtn_Click(object sender, EventArgs e)
        {
            openChildForm(new NewsForm());
        }


        private void Javescriptbtn_Click(object sender, EventArgs e)
        {

        }

        private void Resourcebtn_Click(object sender, EventArgs e)
        {

        }

        private void Informationbtn_Click(object sender, EventArgs e)
        {

        }

        private void Freemenubtn_Click(object sender, EventArgs e)
        {

        }

        private void PremiumMenubtn_Click(object sender, EventArgs e)
        {

        }

        private void iconButton9_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void AboutButton_Click(object sender, EventArgs e)
        {
            About AboutPage = new About();
            AboutPage.Show();
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            
        }

        private void AboutPanel_MouseDown(object sender, MouseEventArgs e)
        {
            mov = 1;
            movX = e.X;
            movY = e.Y;
        }

        private void AboutPanel_MouseMove(object sender, MouseEventArgs e)
        {
            if (mov == 1)
            {
                this.SetDesktopLocation(MousePosition.X - movX, MousePosition.Y - movY);
            }
        }

        private void AboutPanel_MouseUp(object sender, MouseEventArgs e)
        {
            mov = 0;
        }

        private void SubPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void GTAVMain_Load(object sender, EventArgs e)
        {
            protection.AntiDebug = true;
            protection.AntiDump = true;
            protection.AntiProcess = true;

            if (protection.AntiDebug)
            {
                Protection.Debug.Initialize();
                Console.WriteLine("[#] AntiDebug Has Been Initialized.");
            }
            else { }
            //
            if (protection.AntiDump)
            {
                Protection.Dump.Initialize();
                Console.WriteLine("[#] AntiDump Has Been Initialized.");
            }
            else { }
            //
            if (protection.AntiProcess)
            {
                Protection.ProcessCheck.Initialize();
                Console.WriteLine("[#] AntiProcess Has Been Initialized.");
            }
            else
            {

            }

            comboBox1.Text = "Language";
            NameLabel.Text = Login.KeyAuthApp.user_data.username;
            ExpiryLabel.Text = ""+  UnixTimeToDateTime(long.Parse(Login.KeyAuthApp.user_data.subscriptions[0].expiry));


        }
        public DateTime UnixTimeToDateTime(long unixtime)
        {
            System.DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Local);
            dtDateTime = dtDateTime.AddSeconds(unixtime).ToLocalTime();
            return dtDateTime;
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "English")
            {
                var changeLanguage = new ChangeLanguage();
                changeLanguage.UpdateConfig("language", "en");
                Application.Restart();
            }
            else if (comboBox1.Text == "German")
            {
                var changeLanguage = new ChangeLanguage();
                changeLanguage.UpdateConfig("language", "de-DE");
                Application.Restart();
            }
            else if (comboBox1.Text == "Chinesisch")
            {
                var changeLanguage = new ChangeLanguage();
                changeLanguage.UpdateConfig("language", "zh-cn");
                Application.Restart();
            }
        }
    }
}
