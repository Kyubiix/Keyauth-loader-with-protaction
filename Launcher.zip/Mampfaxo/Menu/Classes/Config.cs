﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mampfaxo.Menu.Classes
{
    class Config
    {
        public static string Rank;
       // public static string Rank = User.Rank;
        public static string Plan;
    }
}
