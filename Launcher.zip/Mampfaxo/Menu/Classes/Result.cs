﻿namespace Mampfaxo.Injector
{
    public enum DllInjectionResult
    {
        DllNotFound,
        ProcessNotFound,
        InjectionFailed,
        Success
    }
}
