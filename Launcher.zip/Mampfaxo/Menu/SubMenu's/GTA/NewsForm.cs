﻿using Mampfaxo.Menu.Protection.Control;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mampfaxo
{
    public partial class NewsForm : Form
    {
        static ProtectionProperties protection = new ProtectionProperties();
        public NewsForm()
        {
            InitializeComponent();
        }

        private void NewsForm_Load(object sender, EventArgs e)
        {
            protection.AntiDebug = true;
            protection.AntiDump = true;
            protection.AntiProcess = true;
            if (protection.AntiDebug)
            {
                Protection.Debug.Initialize();
                Console.WriteLine("[#] AntiDebug Has Been Initialized.");
            }
            else { }
            //
            if (protection.AntiDump)
            {
                Protection.Dump.Initialize();
                Console.WriteLine("[#] AntiDump Has Been Initialized.");
            }
            else { }
            //
            if (protection.AntiProcess)
            {
                Protection.ProcessCheck.Initialize();
                Console.WriteLine("[#] AntiProcess Has Been Initialized.");
            }
            else
            {

            }
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {

        }
    }
}
