﻿namespace Mampfaxo
{
    partial class InjectForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InjectForm));
            this.loadingText = new System.Windows.Forms.RichTextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.TabLabel = new System.Windows.Forms.Label();
            this.ClearBtn = new FontAwesome.Sharp.IconButton();
            this.ExecuteBtn = new FontAwesome.Sharp.IconButton();
            this.SuspendLayout();
            // 
            // loadingText
            // 
            resources.ApplyResources(this.loadingText, "loadingText");
            this.loadingText.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(19)))), ((int)(((byte)(18)))));
            this.loadingText.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.loadingText.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(159)))), ((int)(((byte)(221)))));
            this.loadingText.Name = "loadingText";
            this.loadingText.ReadOnly = true;
            // 
            // panel3
            // 
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.panel3.Name = "panel3";
            // 
            // TabLabel
            // 
            resources.ApplyResources(this.TabLabel, "TabLabel");
            this.TabLabel.ForeColor = System.Drawing.Color.White;
            this.TabLabel.Name = "TabLabel";
            // 
            // ClearBtn
            // 
            resources.ApplyResources(this.ClearBtn, "ClearBtn");
            this.ClearBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(8)))), ((int)(((byte)(13)))));
            this.ClearBtn.FlatAppearance.BorderSize = 0;
            this.ClearBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(226)))), ((int)(((byte)(228)))));
            this.ClearBtn.IconChar = FontAwesome.Sharp.IconChar.Eraser;
            this.ClearBtn.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(159)))), ((int)(((byte)(221)))));
            this.ClearBtn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ClearBtn.IconSize = 25;
            this.ClearBtn.Name = "ClearBtn";
            this.ClearBtn.UseVisualStyleBackColor = false;
            this.ClearBtn.Click += new System.EventHandler(this.ClearBtn_Click);
            // 
            // ExecuteBtn
            // 
            resources.ApplyResources(this.ExecuteBtn, "ExecuteBtn");
            this.ExecuteBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(8)))), ((int)(((byte)(13)))));
            this.ExecuteBtn.FlatAppearance.BorderSize = 0;
            this.ExecuteBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(226)))), ((int)(((byte)(228)))));
            this.ExecuteBtn.IconChar = FontAwesome.Sharp.IconChar.Code;
            this.ExecuteBtn.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(159)))), ((int)(((byte)(221)))));
            this.ExecuteBtn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ExecuteBtn.IconSize = 25;
            this.ExecuteBtn.Name = "ExecuteBtn";
            this.ExecuteBtn.UseVisualStyleBackColor = false;
            this.ExecuteBtn.Click += new System.EventHandler(this.ExecuteBtn_Click);
            // 
            // InjectForm
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(8)))), ((int)(((byte)(13)))));
            this.Controls.Add(this.ExecuteBtn);
            this.Controls.Add(this.ClearBtn);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.TabLabel);
            this.Controls.Add(this.loadingText);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "InjectForm";
            this.Load += new System.EventHandler(this.InjectForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox loadingText;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label TabLabel;
        private FontAwesome.Sharp.IconButton ClearBtn;
        private FontAwesome.Sharp.IconButton ExecuteBtn;
    }
}