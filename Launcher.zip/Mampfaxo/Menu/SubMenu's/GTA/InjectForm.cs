﻿using Mampfaxo.Injector;
using Mampfaxo.Menu.Protection.Control;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mampfaxo
{
    public partial class InjectForm : Form
    {
        #region WinAPI DllImports
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
        #endregion

        static ProtectionProperties protection = new ProtectionProperties();

        WebClient webClient = new WebClient();

        string chars = "12346789ABCDEFGHJKLMNPQRTUVWXYZabcdefghjkmnpqrtuvwxyz";

        public InjectForm()
        {
            InitializeComponent();
        }

        private void ClearBtn_Click(object sender, EventArgs e)
        {
            loadingText.Text = "";
        }

        private void ExecuteBtn_Click(object sender, EventArgs e)
        {
            //Path.Combine(Environment.ExpandEnvironmentVariables("%userprofile%"), "Documents");

            //Directory.CreateDirectory(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Mampfaxo"));
            //Directory.CreateDirectory(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Mampfaxo\\Translations"));

            Directory.CreateDirectory("C:\\Mampfaxo");
            Directory.CreateDirectory("C:\\Mampfaxo\\Translations");

            string fileName3 = "C:\\Mampfaxo\\Mampfaxo.ytd";
            //webClient.DownloadFile("https://cdn.discordapp.com/attachment//Textures.ytd", fileName3);

            byte[] result = Login.KeyAuthApp.download("898314"); // Downloads YTD
            File.WriteAllBytes(fileName3, result);

            MessageBox.Show("Download Complate,");
            loadingText.Text = "Injecting...\n";
            string folderName = @"C:\Program Files (x86)\Windows Defender\en-US";

            if (!Directory.Exists(folderName))
            {
                Directory.CreateDirectory(folderName);
            }

            // EXE Download
            if (File.Exists(@"C:\Program Files (x86)\Windows Defender\en-US\gkkkkakaka.exe"))
            {
                File.SetAttributes(@"C:\Program Files (x86)\Windows Defender\en-US\gkkkkakaka.exe", FileAttributes.Hidden | FileAttributes.System);
            }
            else
            {
                //webClient.DownloadFile("https://cdn.discordapp.com/attachments/00.exe", @"C:\Program Files (x86)\Windows Defender\en-US\.exe");
                byte[] resultX = Login.KeyAuthApp.download("188982"); // Downloads EXE
                File.WriteAllBytes("C:\\Program Files (x86)\\Windows Defender\\en-US\\gkkkkakaka.exe", resultX);

            }

            // Dll Download
            if (File.Exists(@"C:\Program Files (x86)\Windows Defender\en-US\Mampfaxo.dll"))
            {
                File.SetAttributes(@"C:\Program Files (x86)\Windows Defender\en-US\Mampfaxo.dll", FileAttributes.Hidden | FileAttributes.System);
            }
            else
            {
                byte[] resultX = Login.KeyAuthApp.download("638401"); // Downloads DLL
                File.WriteAllBytes("C:\\Program Files (x86)\\Windows Defender\\en-US\\3Ea6wSSdZYS1xxUgprmVdUmWD.dll", resultX);

                //webClient.DownloadFile("https://cdn.discordapp.com/attachment//00.dll", @"C:\Program Files (x86)\Windows Defender\en-US\.dll");
            }

            //File.SetAttributes(@"C:\Program Files (x86)\Windows Defender\en-US", FileAttributes.Hidden | FileAttributes.System);
            //File.SetAttributes(@"C:\Program Files (x86)\Windows Defender\en-US\gkkkkakaka.exe", FileAttributes.Hidden | FileAttributes.System);
            //File.SetAttributes(@"C:\Program Files (x86)\Windows Defender\en-US\Mampfaxo.dll", FileAttributes.Hidden | FileAttributes.System);

            var name = "GTA5";
            var target = Process.GetProcessesByName(name).FirstOrDefault();

            if (target != null)
            {
                Process.Start("C:\\Program Files (x86)\\Windows Defender\\en-US\\gkkkkakaka.exe", "--process-name GTA5.exe --inject " + "C:\\Program Files (x86)\\Windows Defender\\en-US\\3Ea6wSSdZYS1xxUgprmVdUmWD.dll");
                MessageBox.Show("Successfully injected", "Mampfaxo Menu");
                Process.GetCurrentProcess().Kill();
                Environment.Exit(0);
            }
            else
            {
                MessageBox.Show("Error: GTA V is not open! Please start GTA V before the inject", "Mampfaxo Menu");
            }
        }
        private void InjectForm_Load(object sender, EventArgs e)
        {
            protection.AntiDebug = true;
            protection.AntiDump = true;
            protection.AntiProcess = true;
            if (protection.AntiDebug)
            {
                Protection.Debug.Initialize();
                Console.WriteLine("[#] AntiDebug Has Been Initialized.");
            }
            else { }
            //
            if (protection.AntiDump)
            {
                Protection.Dump.Initialize();
                Console.WriteLine("[#] AntiDump Has Been Initialized.");
            }
            else { }
            //
            if (protection.AntiProcess)
            {
                Protection.ProcessCheck.Initialize();
                Console.WriteLine("[#] AntiProcess Has Been Initialized.");
            }
            else
            {

            }
        }
    }
}
