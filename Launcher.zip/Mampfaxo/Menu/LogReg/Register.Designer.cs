﻿namespace Mampfaxo
{
    partial class Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Register));
            this.iconButton2 = new FontAwesome.Sharp.IconButton();
            this.RegisterLabel = new System.Windows.Forms.Label();
            this.logoLabel = new System.Windows.Forms.Label();
            this.SignupButton = new FontAwesome.Sharp.IconButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.password = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.username = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.license = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.email = new System.Windows.Forms.TextBox();
            this.iconButton1 = new FontAwesome.Sharp.IconButton();
            this.checkPassword = new System.Windows.Forms.CheckBox();
            this.profilePicture3 = new Mampfaxo.ProfilePicture();
            this.profilePicture2 = new Mampfaxo.ProfilePicture();
            this.profilePicture1 = new Mampfaxo.ProfilePicture();
            ((System.ComponentModel.ISupportInitialize)(this.profilePicture3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.profilePicture2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.profilePicture1)).BeginInit();
            this.SuspendLayout();
            // 
            // iconButton2
            // 
            this.iconButton2.FlatAppearance.BorderSize = 0;
            this.iconButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton2.ForeColor = System.Drawing.Color.White;
            this.iconButton2.IconChar = FontAwesome.Sharp.IconChar.Times;
            this.iconButton2.IconColor = System.Drawing.Color.White;
            this.iconButton2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton2.IconSize = 17;
            this.iconButton2.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.iconButton2.Location = new System.Drawing.Point(289, 0);
            this.iconButton2.Name = "iconButton2";
            this.iconButton2.Size = new System.Drawing.Size(25, 25);
            this.iconButton2.TabIndex = 22;
            this.iconButton2.UseVisualStyleBackColor = true;
            this.iconButton2.Click += new System.EventHandler(this.iconButton2_Click);
            // 
            // RegisterLabel
            // 
            this.RegisterLabel.AutoSize = true;
            this.RegisterLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RegisterLabel.ForeColor = System.Drawing.Color.White;
            this.RegisterLabel.Location = new System.Drawing.Point(120, 38);
            this.RegisterLabel.Name = "RegisterLabel";
            this.RegisterLabel.Size = new System.Drawing.Size(72, 21);
            this.RegisterLabel.TabIndex = 18;
            this.RegisterLabel.Text = "Register";
            // 
            // logoLabel
            // 
            this.logoLabel.AutoSize = true;
            this.logoLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoLabel.ForeColor = System.Drawing.Color.White;
            this.logoLabel.Location = new System.Drawing.Point(97, 8);
            this.logoLabel.Name = "logoLabel";
            this.logoLabel.Size = new System.Drawing.Size(81, 30);
            this.logoLabel.TabIndex = 17;
            this.logoLabel.Text = "Mampfaxo";
            this.logoLabel.Click += new System.EventHandler(this.logoLabel_Click);
            // 
            // SignupButton
            // 
            this.SignupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(18)))), ((int)(((byte)(33)))));
            this.SignupButton.FlatAppearance.BorderSize = 0;
            this.SignupButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SignupButton.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SignupButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(226)))), ((int)(((byte)(228)))));
            this.SignupButton.IconChar = FontAwesome.Sharp.IconChar.Check;
            this.SignupButton.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(226)))), ((int)(((byte)(228)))));
            this.SignupButton.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.SignupButton.IconSize = 24;
            this.SignupButton.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.SignupButton.Location = new System.Drawing.Point(77, 280);
            this.SignupButton.Name = "SignupButton";
            this.SignupButton.Size = new System.Drawing.Size(149, 38);
            this.SignupButton.TabIndex = 16;
            this.SignupButton.Text = "Sign Up";
            this.SignupButton.UseVisualStyleBackColor = false;
            this.SignupButton.Click += new System.EventHandler(this.SignupButton_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(25)))), ((int)(((byte)(37)))));
            this.panel2.Location = new System.Drawing.Point(70, 166);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(170, 2);
            this.panel2.TabIndex = 15;
            // 
            // password
            // 
            this.password.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(8)))), ((int)(((byte)(13)))));
            this.password.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.password.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.password.ForeColor = System.Drawing.Color.White;
            this.password.Location = new System.Drawing.Point(77, 144);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(156, 16);
            this.password.TabIndex = 14;
            this.password.Text = "Password";
            this.password.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.password.UseSystemPasswordChar = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(25)))), ((int)(((byte)(37)))));
            this.panel1.Location = new System.Drawing.Point(70, 118);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(170, 2);
            this.panel1.TabIndex = 13;
            // 
            // username
            // 
            this.username.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(8)))), ((int)(((byte)(13)))));
            this.username.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.username.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.username.ForeColor = System.Drawing.Color.White;
            this.username.Location = new System.Drawing.Point(77, 96);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(156, 16);
            this.username.TabIndex = 12;
            this.username.Text = "Username";
            this.username.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(25)))), ((int)(((byte)(37)))));
            this.panel3.Location = new System.Drawing.Point(70, 257);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(170, 2);
            this.panel3.TabIndex = 19;
            // 
            // license
            // 
            this.license.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(8)))), ((int)(((byte)(13)))));
            this.license.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.license.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.license.ForeColor = System.Drawing.Color.White;
            this.license.Location = new System.Drawing.Point(77, 235);
            this.license.Name = "license";
            this.license.Size = new System.Drawing.Size(156, 16);
            this.license.TabIndex = 18;
            this.license.Text = "License";
            this.license.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(25)))), ((int)(((byte)(37)))));
            this.panel4.Location = new System.Drawing.Point(70, 209);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(170, 2);
            this.panel4.TabIndex = 17;
            // 
            // email
            // 
            this.email.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(8)))), ((int)(((byte)(13)))));
            this.email.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.email.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email.ForeColor = System.Drawing.Color.White;
            this.email.Location = new System.Drawing.Point(77, 187);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(156, 16);
            this.email.TabIndex = 16;
            this.email.Text = "E-mail";
            this.email.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // iconButton1
            // 
            this.iconButton1.FlatAppearance.BorderSize = 0;
            this.iconButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton1.ForeColor = System.Drawing.Color.White;
            this.iconButton1.IconChar = FontAwesome.Sharp.IconChar.ArrowLeft;
            this.iconButton1.IconColor = System.Drawing.Color.White;
            this.iconButton1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton1.IconSize = 17;
            this.iconButton1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.iconButton1.Location = new System.Drawing.Point(0, 0);
            this.iconButton1.Name = "iconButton1";
            this.iconButton1.Size = new System.Drawing.Size(25, 25);
            this.iconButton1.TabIndex = 23;
            this.iconButton1.UseVisualStyleBackColor = true;
            this.iconButton1.Click += new System.EventHandler(this.iconButton1_Click);
            // 
            // checkPassword
            // 
            this.checkPassword.AutoSize = true;
            this.checkPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkPassword.ForeColor = System.Drawing.Color.White;
            this.checkPassword.Location = new System.Drawing.Point(247, 142);
            this.checkPassword.Name = "checkPassword";
            this.checkPassword.Size = new System.Drawing.Size(50, 28);
            this.checkPassword.TabIndex = 24;
            this.checkPassword.Text = "👁";
            this.checkPassword.UseVisualStyleBackColor = true;
            this.checkPassword.CheckedChanged += new System.EventHandler(this.checkPassword_CheckedChanged);
            // 
            // profilePicture3
            // 
            this.profilePicture3.Image = ((System.Drawing.Image)(resources.GetObject("profilePicture3.Image")));
            this.profilePicture3.Location = new System.Drawing.Point(247, 332);
            this.profilePicture3.Name = "profilePicture3";
            this.profilePicture3.Size = new System.Drawing.Size(40, 40);
            this.profilePicture3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.profilePicture3.TabIndex = 21;
            this.profilePicture3.TabStop = false;
            // 
            // profilePicture2
            // 
            this.profilePicture2.Image = ((System.Drawing.Image)(resources.GetObject("profilePicture2.Image")));
            this.profilePicture2.Location = new System.Drawing.Point(135, 332);
            this.profilePicture2.Name = "profilePicture2";
            this.profilePicture2.Size = new System.Drawing.Size(40, 40);
            this.profilePicture2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.profilePicture2.TabIndex = 20;
            this.profilePicture2.TabStop = false;
            this.profilePicture2.Click += new System.EventHandler(this.profilePicture2_Click);
            // 
            // profilePicture1
            // 
            this.profilePicture1.Image = ((System.Drawing.Image)(resources.GetObject("profilePicture1.Image")));
            this.profilePicture1.Location = new System.Drawing.Point(27, 332);
            this.profilePicture1.Name = "profilePicture1";
            this.profilePicture1.Size = new System.Drawing.Size(40, 40);
            this.profilePicture1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.profilePicture1.TabIndex = 19;
            this.profilePicture1.TabStop = false;
            this.profilePicture1.Click += new System.EventHandler(this.profilePicture1_Click);
            // 
            // Register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(8)))), ((int)(((byte)(13)))));
            this.ClientSize = new System.Drawing.Size(314, 381);
            this.Controls.Add(this.checkPassword);
            this.Controls.Add(this.iconButton1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.iconButton2);
            this.Controls.Add(this.license);
            this.Controls.Add(this.profilePicture3);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.email);
            this.Controls.Add(this.profilePicture2);
            this.Controls.Add(this.profilePicture1);
            this.Controls.Add(this.RegisterLabel);
            this.Controls.Add(this.logoLabel);
            this.Controls.Add(this.SignupButton);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.password);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.username);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Register";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Register ";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Register_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Register_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Register_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Register_MouseUp);
            ((System.ComponentModel.ISupportInitialize)(this.profilePicture3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.profilePicture2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.profilePicture1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private FontAwesome.Sharp.IconButton iconButton2;
        private ProfilePicture profilePicture3;
        private ProfilePicture profilePicture2;
        private ProfilePicture profilePicture1;
        private System.Windows.Forms.Label RegisterLabel;
        private System.Windows.Forms.Label logoLabel;
        private FontAwesome.Sharp.IconButton SignupButton;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox username;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox license;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox email;
        private FontAwesome.Sharp.IconButton iconButton1;
        private System.Windows.Forms.CheckBox checkPassword;
    }
}