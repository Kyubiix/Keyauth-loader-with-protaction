﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics;
using Microsoft.Win32;
using Mampfaxo.Menu.Protection.Control;
using KeyAuth;
using System.IO;

namespace Mampfaxo
{
    public partial class Login : Form
    {
        static ProtectionProperties protection = new ProtectionProperties();

        int mov;
        int movX;
        int movY;

        static string name = "Mampfaxo"; // application name. right above the blurred text aka the secret on the licenses tab among other tabs
        static string ownerid = "PQPv9TAEFE"; // ownerid, found in account settings. click your profile picture on top right of dashboard and then account settings.
        static string secret = "aae03868bc38b2d2bb24b923b5f0a25050fb062e934a57121399f1faf0c46192"; // app secret, the blurred text on licenses tab and other tabs
        static string version = "1.0"; // leave alone unless you've changed version on website

        public static api KeyAuthApp = new api(name, ownerid, secret, version);

        public Login()
        {
            InitializeComponent();
        }

        public void saveData()
        {
            RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Mampfaxo");
            registryKey.SetValue("1", this.username.Text);
            registryKey.SetValue("2", this.password.Text);
            registryKey.Close();
        }

        public void requestData()
        {
            try
            {
                RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Mampfaxo");
                object value = registryKey.GetValue("1");
                object value2 = registryKey.GetValue("2");
                registryKey.Close();
                this.username.Text = value.ToString();
                this.password.Text = value2.ToString();
            }
            catch
            {
              
            }
        }

        private void profilePicture1_Click(object sender, EventArgs e)
        {
            Process.Start("https://www.youtube.com/channel/UC3LnU_GaXIEeOhwKdlAZS_A");
        }

        private void profilePicture2_Click(object sender, EventArgs e)
        {
            Process.Start("https://discord.gg/");
        }

        private void profilePicture3_Click(object sender, EventArgs e)
        {
           // Process.Start("");
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Register Register = new Register();
            Register.Show();
            this.Hide();
        }

        private void SigninButton_Click(object sender, EventArgs e)
        {
            if (KeyAuthApp.login(username.Text, password.Text))
            {
                //Put code here of what you want to do after successful login
                saveData();
                KeyAuthApp.log( username.Text + " Logged In");
                Main Login = new Main();
                Login.Show();
                this.Hide();
            }
        }

        private void checkPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (checkPassword.Checked)
            {
                password.UseSystemPasswordChar = false;
            }
            else
            {
                password.UseSystemPasswordChar = true;
            }
        }

        private void Login_MouseDown(object sender, MouseEventArgs e)
        {
            mov = 1;
            movX = e.X;
            movY = e.Y;
        }

        private void Login_MouseMove(object sender, MouseEventArgs e)
        {
            if (mov == 1)
            {
              this.SetDesktopLocation(MousePosition.X - movX, MousePosition.Y - movY);
            }
        }

        private void Login_MouseUp(object sender, MouseEventArgs e)
        {
            mov = 0;
        }

        private void Login_Load(object sender, EventArgs e)
        {   
            KeyAuthApp.init();

            protection.AntiDebug = true;
            protection.AntiDump = true;
            protection.AntiProcess = true;
            KeyAuthApp.init();
            if (protection.AntiDebug)
            {
                Protection.Debug.Initialize();
                Console.WriteLine("[#] AntiDebug Has Been Initialized.");
            }
            else { }
            //
            if (protection.AntiDump)
            {
                Protection.Dump.Initialize();
                Console.WriteLine("[#] AntiDump Has Been Initialized.");
            }
            else { }
            //
            if (protection.AntiProcess)
            {
                Protection.ProcessCheck.Initialize();
                Console.WriteLine("[#] AntiProcess Has Been Initialized.");
            }
            else
            {

            }
            requestData();
        }
    }
}
