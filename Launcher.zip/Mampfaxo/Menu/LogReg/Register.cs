﻿using Mampfaxo.Menu.Protection.Control;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mampfaxo
{
    public partial class Register : Form
    {
        static ProtectionProperties protection = new ProtectionProperties();

        int mov;
        int movX;
        int movY;

        public Register()
        {
            InitializeComponent();
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            Login Login = new Login();
            Login.Show();
            this.Hide();
        }

        private void checkPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (checkPassword.Checked)
            {
                password.UseSystemPasswordChar = false;
            }
            else
            {
                password.UseSystemPasswordChar = true;
            }
        }

        private void Register_MouseDown(object sender, MouseEventArgs e)
        {
            mov = 1;
            movX = e.X;
            movY = e.Y;
        }

        private void Register_MouseMove(object sender, MouseEventArgs e)
        {
            if (mov == 1)
            {
                this.SetDesktopLocation(MousePosition.X - movX, MousePosition.Y - movY);
            }
        }

        private void Register_MouseUp(object sender, MouseEventArgs e)
        {
            mov = 0;
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void logoLabel_Click(object sender, EventArgs e)
        {

        }

        private void SignupButton_Click(object sender, EventArgs e)
        {
            if (Login.KeyAuthApp.register(username.Text, password.Text, license.Text))

            {
               MessageBox.Show("Register has been successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
               Login.KeyAuthApp.log(username.Text + " Hes Been Registered");

            }
        }

        private void profilePicture2_Click(object sender, EventArgs e)
        {
            Process.Start("https://discord.gg/");

        }

        private void profilePicture1_Click(object sender, EventArgs e)
        {
            Process.Start("https://www.youtube.com/channel/UC3LnU_GaXIEeOhwKdlAZS_A");

        }

        private void Register_Load(object sender, EventArgs e)
        {
            protection.AntiDebug = true;
            protection.AntiDump = true;
            protection.AntiProcess = true;
            if (protection.AntiDebug)
            {
                Protection.Debug.Initialize();
                Console.WriteLine("[#] AntiDebug Has Been Initialized.");
            }
            else { }
            //
            if (protection.AntiDump)
            {
                Protection.Dump.Initialize();
                Console.WriteLine("[#] AntiDump Has Been Initialized.");
            }
            else { }
            //
            if (protection.AntiProcess)
            {
                Protection.ProcessCheck.Initialize();
                Console.WriteLine("[#] AntiProcess Has Been Initialized.");
            }
            else
            {

            }
        }
    }
}
