﻿namespace Mampfaxo
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.username = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.password = new System.Windows.Forms.TextBox();
            this.SigninButton = new FontAwesome.Sharp.IconButton();
            this.logoLabel = new System.Windows.Forms.Label();
            this.LoginLabel = new System.Windows.Forms.Label();
            this.iconButton2 = new FontAwesome.Sharp.IconButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.checkPassword = new System.Windows.Forms.CheckBox();
            this.profilePicture3 = new Mampfaxo.ProfilePicture();
            this.profilePicture2 = new Mampfaxo.ProfilePicture();
            this.profilePicture1 = new Mampfaxo.ProfilePicture();
            ((System.ComponentModel.ISupportInitialize)(this.profilePicture3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.profilePicture2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.profilePicture1)).BeginInit();
            this.SuspendLayout();
            // 
            // username
            // 
            resources.ApplyResources(this.username, "username");
            this.username.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(8)))), ((int)(((byte)(13)))));
            this.username.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.username.ForeColor = System.Drawing.Color.White;
            this.username.Name = "username";
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(25)))), ((int)(((byte)(37)))));
            this.panel1.Name = "panel1";
            // 
            // panel2
            // 
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(25)))), ((int)(((byte)(37)))));
            this.panel2.Name = "panel2";
            // 
            // password
            // 
            resources.ApplyResources(this.password, "password");
            this.password.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(8)))), ((int)(((byte)(13)))));
            this.password.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.password.ForeColor = System.Drawing.Color.White;
            this.password.Name = "password";
            this.password.UseSystemPasswordChar = true;
            // 
            // SigninButton
            // 
            resources.ApplyResources(this.SigninButton, "SigninButton");
            this.SigninButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(18)))), ((int)(((byte)(33)))));
            this.SigninButton.FlatAppearance.BorderSize = 0;
            this.SigninButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(226)))), ((int)(((byte)(228)))));
            this.SigninButton.IconChar = FontAwesome.Sharp.IconChar.Check;
            this.SigninButton.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(226)))), ((int)(((byte)(228)))));
            this.SigninButton.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.SigninButton.IconSize = 24;
            this.SigninButton.Name = "SigninButton";
            this.SigninButton.UseVisualStyleBackColor = false;
            this.SigninButton.Click += new System.EventHandler(this.SigninButton_Click);
            // 
            // logoLabel
            // 
            resources.ApplyResources(this.logoLabel, "logoLabel");
            this.logoLabel.ForeColor = System.Drawing.Color.White;
            this.logoLabel.Name = "logoLabel";
            // 
            // LoginLabel
            // 
            resources.ApplyResources(this.LoginLabel, "LoginLabel");
            this.LoginLabel.ForeColor = System.Drawing.Color.White;
            this.LoginLabel.Name = "LoginLabel";
            // 
            // iconButton2
            // 
            resources.ApplyResources(this.iconButton2, "iconButton2");
            this.iconButton2.FlatAppearance.BorderSize = 0;
            this.iconButton2.ForeColor = System.Drawing.Color.White;
            this.iconButton2.IconChar = FontAwesome.Sharp.IconChar.Times;
            this.iconButton2.IconColor = System.Drawing.Color.White;
            this.iconButton2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton2.IconSize = 17;
            this.iconButton2.Name = "iconButton2";
            this.iconButton2.UseVisualStyleBackColor = true;
            this.iconButton2.Click += new System.EventHandler(this.iconButton2_Click);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Name = "label1";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Name = "label2";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(164)))), ((int)(((byte)(240)))));
            this.label3.Name = "label3";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Name = "label4";
            // 
            // checkPassword
            // 
            resources.ApplyResources(this.checkPassword, "checkPassword");
            this.checkPassword.ForeColor = System.Drawing.Color.White;
            this.checkPassword.Name = "checkPassword";
            this.checkPassword.UseVisualStyleBackColor = true;
            this.checkPassword.CheckedChanged += new System.EventHandler(this.checkPassword_CheckedChanged);
            // 
            // profilePicture3
            // 
            resources.ApplyResources(this.profilePicture3, "profilePicture3");
            this.profilePicture3.Name = "profilePicture3";
            this.profilePicture3.TabStop = false;
            this.profilePicture3.Click += new System.EventHandler(this.profilePicture3_Click);
            // 
            // profilePicture2
            // 
            resources.ApplyResources(this.profilePicture2, "profilePicture2");
            this.profilePicture2.Name = "profilePicture2";
            this.profilePicture2.TabStop = false;
            this.profilePicture2.Click += new System.EventHandler(this.profilePicture2_Click);
            // 
            // profilePicture1
            // 
            resources.ApplyResources(this.profilePicture1, "profilePicture1");
            this.profilePicture1.Name = "profilePicture1";
            this.profilePicture1.TabStop = false;
            this.profilePicture1.Click += new System.EventHandler(this.profilePicture1_Click);
            // 
            // Login
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(8)))), ((int)(((byte)(13)))));
            this.Controls.Add(this.checkPassword);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.iconButton2);
            //this.Controls.Add(this.profilePicture3);
            //this.Controls.Add(this.profilePicture2);
            //this.Controls.Add(this.profilePicture1);
            this.Controls.Add(this.LoginLabel);
            this.Controls.Add(this.logoLabel);
            this.Controls.Add(this.SigninButton);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.password);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.username);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Login";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Login_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Login_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Login_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Login_MouseUp);
            ((System.ComponentModel.ISupportInitialize)(this.profilePicture3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.profilePicture2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.profilePicture1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox username;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox password;
        private FontAwesome.Sharp.IconButton SigninButton;
        private System.Windows.Forms.Label logoLabel;
        private System.Windows.Forms.Label LoginLabel;
        private ProfilePicture profilePicture1;
        private ProfilePicture profilePicture2;
        private ProfilePicture profilePicture3;
        private FontAwesome.Sharp.IconButton iconButton2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox checkPassword;
    }
}