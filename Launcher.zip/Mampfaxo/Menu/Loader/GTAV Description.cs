﻿using Mampfaxo.Menu.Protection.Control;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mampfaxo
{
    public partial class GTAV_Description : Form
    {
        static ProtectionProperties protection = new ProtectionProperties();
        public GTAV_Description()
        {
            InitializeComponent();
        }

        private void GameLabel_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void GTAV_Description_Load(object sender, EventArgs e)
        {
            protection.AntiDebug = true;
            protection.AntiDump = true;
            protection.AntiProcess = true;
            if (protection.AntiDebug)
            {
                Protection.Debug.Initialize();
                Console.WriteLine("[#] AntiDebug Has Been Initialized.");
            }
            else { }
            //
            if (protection.AntiDump)
            {
                Protection.Dump.Initialize();
                Console.WriteLine("[#] AntiDump Has Been Initialized.");
            }
            else { }
            //
            if (protection.AntiProcess)
            {
                Protection.ProcessCheck.Initialize();
                Console.WriteLine("[#] AntiProcess Has Been Initialized.");
            }
            else
            {

            }
            label2.Text = "Today: " + DateTime.Now.ToString();
            label4.Text= "Expire: " + UnixTimeToDateTime(long.Parse(Login.KeyAuthApp.user_data.subscriptions[0].expiry));
        }
        public DateTime UnixTimeToDateTime(long unixtime)
        {
            System.DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Local);
            dtDateTime = dtDateTime.AddSeconds(unixtime).ToLocalTime();
            return dtDateTime;
        }
    }
}
