﻿using Newtonsoft.Json;
using System.Globalization;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Mampfaxo.Menu.Protection.Control;
using Mampfaxo.Menu.Classes;

namespace Mampfaxo
{
    public partial class Main : Form
    {
        static ProtectionProperties protection = new ProtectionProperties();

        WebClient PanelAdmin = new WebClient();
        public static string authgg = "https://developers.auth.gg";
        public static string API = "DZMMWWDVRVUE"; // ad your API

        int mov;
        int movX;
        int movY;


        public Main()
        {
            InitializeComponent();
        }

        //Mouse enter and Leave events
        private void gameFiveM_MouseEnter(object sender, EventArgs e)
        {
            this.gameFiveM.BackColor = ColorTranslator.FromHtml("#04334d");
        }

        private void gameFiveM_MouseLeave(object sender, EventArgs e)
        {
            this.gameFiveM.BackColor = ColorTranslator.FromHtml("#030d1a");
        }

        //Game Subscription button click events.
        private void gameFiveM_Click(object sender, EventArgs e)
        {
            GameLabel.Text = "GTA V";
            openChildForm(new GTAV_Description());
            this.iconButton1.Name = "GTA V Launch";
        }

     
        //OpenChildForm
        private Form activeForm = null;
        private void openChildForm(Form childForm)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            DescriptionPanel.Controls.Add(childForm);
            DescriptionPanel.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            if (this.iconButton1.Name == "GTA V Launch")
            {
                GTAVMain Main = new GTAVMain();
                Main.Show();
                this.Hide();
            }
            else if (this.iconButton1.Name == "CSGO Launch")
            {

            }
        }

        private void Main_MouseDown(object sender, MouseEventArgs e)
        {
            mov = 1;
            movX = e.X;
            movY = e.Y;
        }

        private void Main_MouseMove(object sender, MouseEventArgs e)
        {
            if (mov == 1)
            {
                this.SetDesktopLocation(MousePosition.X - movX, MousePosition.Y - movY);
            }
        }

        private void Main_MouseUp(object sender, MouseEventArgs e)
        {
            mov = 0;
        }

        private void Main_Load(object sender, EventArgs e)
        {

            if (Config.Rank == "0") { Config.Plan = "Free"; }
            if (Config.Rank == "0") { label1.Text = "Subscriptions = Free"; }
            if (Config.Rank == "5") { btnAdmin.Visible = false; }

            if (Config.Rank == "1") { Config.Plan = "Standard"; }
            if (Config.Rank == "1") { label1.Text = "Subscriptions = Standard"; }
            if (Config.Rank == "5") { btnAdmin.Visible = false; }

            if (Config.Rank == "2") { Config.Plan = "VIP"; }
            if (Config.Rank == "2") { label1.Text = "Subscriptions = VIP"; }
            if (Config.Rank == "5") { btnAdmin.Visible = false; }

            if (Config.Rank == "5") { Config.Plan = "Admin"; }
            if (Config.Rank == "5") { label1.Text = "Subscriptions = Admin"; }
            if (Config.Rank == "5") { btnAdmin.Visible = true; }


            if (protection.AntiDebug)
            {
                Protection.Debug.Initialize();
                Console.WriteLine("[#] AntiDebug Has Been Initialized.");
            }
            else { }
            //
            if (protection.AntiDump)
            {
                Protection.Dump.Initialize();
                Console.WriteLine("[#] AntiDump Has Been Initialized.");
            }
            else { }
            //
            if (protection.AntiProcess)
            {
                Protection.ProcessCheck.Initialize();
                Console.WriteLine("[#] AntiProcess Has Been Initialized.");
            }
            else
            {

            }

            lblUserCounter.Text = PanelAdmin.DownloadString(authgg + "/LICENSES/?type=count&authorization=" + API);

            userLabel.Text = Login.KeyAuthApp.user_data.username;

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            protection.AntiDebug = true;
            protection.AntiDump = true;
            protection.AntiProcess = true;
        }

        private void btnAdmin_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Create Admin Panel Form and link it");
        }
    }
}
