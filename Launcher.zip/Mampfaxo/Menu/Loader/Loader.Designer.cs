﻿namespace Mampfaxo
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.SidePanel = new System.Windows.Forms.Panel();
            this.btnAdmin = new FontAwesome.Sharp.IconButton();
            this.lblUserCounter = new System.Windows.Forms.Label();
            this.ActivityLabel = new System.Windows.Forms.Label();
            this.StatusLabel = new System.Windows.Forms.Label();
            this.userLabel = new System.Windows.Forms.Label();
            this.profilePicture1 = new Mampfaxo.ProfilePicture();
            this.gameFiveM = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.logoLabel = new System.Windows.Forms.Label();
            this.VerticalPanel = new System.Windows.Forms.Panel();
            this.HorizontalPanelTop = new System.Windows.Forms.Panel();
            this.GameLabel = new System.Windows.Forms.Label();
            this.iconButton1 = new FontAwesome.Sharp.IconButton();
            this.DescriptionPanel = new System.Windows.Forms.Panel();
            this.iconButton2 = new FontAwesome.Sharp.IconButton();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SidePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.profilePicture1)).BeginInit();
            this.SuspendLayout();
            // 
            // SidePanel
            // 
            resources.ApplyResources(this.SidePanel, "SidePanel");
            this.SidePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(13)))), ((int)(((byte)(26)))));
            this.SidePanel.Controls.Add(this.btnAdmin);
            this.SidePanel.Controls.Add(this.lblUserCounter);
            this.SidePanel.Controls.Add(this.ActivityLabel);
            this.SidePanel.Controls.Add(this.StatusLabel);
            this.SidePanel.Controls.Add(this.userLabel);
            this.SidePanel.Controls.Add(this.profilePicture1);
            this.SidePanel.Controls.Add(this.gameFiveM);
            this.SidePanel.Controls.Add(this.panel1);
            this.SidePanel.Controls.Add(this.label1);
            this.SidePanel.Controls.Add(this.logoLabel);
            this.SidePanel.Name = "SidePanel";
            // 
            // btnAdmin
            // 
            resources.ApplyResources(this.btnAdmin, "btnAdmin");
            this.btnAdmin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(18)))), ((int)(((byte)(33)))));
            this.btnAdmin.FlatAppearance.BorderSize = 0;
            this.btnAdmin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(226)))), ((int)(((byte)(228)))));
            this.btnAdmin.IconChar = FontAwesome.Sharp.IconChar.Play;
            this.btnAdmin.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(226)))), ((int)(((byte)(228)))));
            this.btnAdmin.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnAdmin.IconSize = 24;
            this.btnAdmin.Name = "btnAdmin";
            this.btnAdmin.UseVisualStyleBackColor = false;
            this.btnAdmin.Click += new System.EventHandler(this.btnAdmin_Click);
            // 
            // lblUserCounter
            // 
            resources.ApplyResources(this.lblUserCounter, "lblUserCounter");
            this.lblUserCounter.ForeColor = System.Drawing.Color.White;
            this.lblUserCounter.Name = "lblUserCounter";
            // 
            // ActivityLabel
            // 
            resources.ApplyResources(this.ActivityLabel, "ActivityLabel");
            this.ActivityLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(164)))), ((int)(((byte)(240)))));
            this.ActivityLabel.Name = "ActivityLabel";
            // 
            // StatusLabel
            // 
            resources.ApplyResources(this.StatusLabel, "StatusLabel");
            this.StatusLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(62)))), ((int)(((byte)(75)))));
            this.StatusLabel.Name = "StatusLabel";
            // 
            // userLabel
            // 
            resources.ApplyResources(this.userLabel, "userLabel");
            this.userLabel.ForeColor = System.Drawing.Color.White;
            this.userLabel.Name = "userLabel";
            // 
            // profilePicture1
            // 
            resources.ApplyResources(this.profilePicture1, "profilePicture1");
            this.profilePicture1.Name = "profilePicture1";
            this.profilePicture1.TabStop = false;
            // 
            // gameFiveM
            // 
            resources.ApplyResources(this.gameFiveM, "gameFiveM");
            this.gameFiveM.FlatAppearance.BorderSize = 0;
            this.gameFiveM.ForeColor = System.Drawing.Color.White;
            this.gameFiveM.Name = "gameFiveM";
            this.gameFiveM.UseVisualStyleBackColor = true;
            this.gameFiveM.Click += new System.EventHandler(this.gameFiveM_Click);
            this.gameFiveM.MouseEnter += new System.EventHandler(this.gameFiveM_MouseEnter);
            this.gameFiveM.MouseLeave += new System.EventHandler(this.gameFiveM_MouseLeave);
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(28)))), ((int)(((byte)(46)))));
            this.panel1.Name = "panel1";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(56)))), ((int)(((byte)(69)))));
            this.label1.Name = "label1";
            // 
            // logoLabel
            // 
            resources.ApplyResources(this.logoLabel, "logoLabel");
            this.logoLabel.ForeColor = System.Drawing.Color.White;
            this.logoLabel.Name = "logoLabel";
            // 
            // VerticalPanel
            // 
            resources.ApplyResources(this.VerticalPanel, "VerticalPanel");
            this.VerticalPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(25)))), ((int)(((byte)(37)))));
            this.VerticalPanel.Name = "VerticalPanel";
            // 
            // HorizontalPanelTop
            // 
            resources.ApplyResources(this.HorizontalPanelTop, "HorizontalPanelTop");
            this.HorizontalPanelTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(25)))), ((int)(((byte)(37)))));
            this.HorizontalPanelTop.Name = "HorizontalPanelTop";
            // 
            // GameLabel
            // 
            resources.ApplyResources(this.GameLabel, "GameLabel");
            this.GameLabel.ForeColor = System.Drawing.Color.White;
            this.GameLabel.Name = "GameLabel";
            // 
            // iconButton1
            // 
            resources.ApplyResources(this.iconButton1, "iconButton1");
            this.iconButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(18)))), ((int)(((byte)(33)))));
            this.iconButton1.FlatAppearance.BorderSize = 0;
            this.iconButton1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(226)))), ((int)(((byte)(228)))));
            this.iconButton1.IconChar = FontAwesome.Sharp.IconChar.Play;
            this.iconButton1.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(226)))), ((int)(((byte)(228)))));
            this.iconButton1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton1.IconSize = 24;
            this.iconButton1.Name = "iconButton1";
            this.iconButton1.UseVisualStyleBackColor = false;
            this.iconButton1.Click += new System.EventHandler(this.iconButton1_Click);
            // 
            // DescriptionPanel
            // 
            resources.ApplyResources(this.DescriptionPanel, "DescriptionPanel");
            this.DescriptionPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(8)))), ((int)(((byte)(13)))));
            this.DescriptionPanel.Name = "DescriptionPanel";
            // 
            // iconButton2
            // 
            resources.ApplyResources(this.iconButton2, "iconButton2");
            this.iconButton2.FlatAppearance.BorderSize = 0;
            this.iconButton2.ForeColor = System.Drawing.Color.White;
            this.iconButton2.IconChar = FontAwesome.Sharp.IconChar.Times;
            this.iconButton2.IconColor = System.Drawing.Color.White;
            this.iconButton2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton2.IconSize = 17;
            this.iconButton2.Name = "iconButton2";
            this.iconButton2.UseVisualStyleBackColor = true;
            this.iconButton2.Click += new System.EventHandler(this.iconButton2_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 300;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Main
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(8)))), ((int)(((byte)(13)))));
            this.Controls.Add(this.iconButton2);
            this.Controls.Add(this.DescriptionPanel);
            this.Controls.Add(this.iconButton1);
            this.Controls.Add(this.GameLabel);
            this.Controls.Add(this.HorizontalPanelTop);
            this.Controls.Add(this.VerticalPanel);
            this.Controls.Add(this.SidePanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Main";
            this.Load += new System.EventHandler(this.Main_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Main_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Main_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Main_MouseUp);
            this.SidePanel.ResumeLayout(false);
            this.SidePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.profilePicture1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel SidePanel;
        private System.Windows.Forms.Panel VerticalPanel;
        private System.Windows.Forms.Panel HorizontalPanelTop;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label logoLabel;
        private System.Windows.Forms.Label GameLabel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button gameFiveM;
        private FontAwesome.Sharp.IconButton iconButton1;
        private ProfilePicture profilePicture1;
        private System.Windows.Forms.Label ActivityLabel;
        private System.Windows.Forms.Label StatusLabel;
        private System.Windows.Forms.Label userLabel;
        private System.Windows.Forms.Panel DescriptionPanel;
        private FontAwesome.Sharp.IconButton iconButton2;
        private System.Windows.Forms.Label lblUserCounter;
        private System.Windows.Forms.Timer timer1;
        private FontAwesome.Sharp.IconButton btnAdmin;
    }
}

