﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Mampfaxo.Menu.Protection.Control;

namespace Mampfaxo
{
    static class Program
    {
        static ProtectionProperties protection = new ProtectionProperties();

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread] 
        static void Main()
        {
            protection.AntiDebug = true;
            protection.AntiDump = true;
            protection.AntiProcess = true;

            if (protection.AntiDebug)
            {
                Protection.Debug.Initialize();
                Console.WriteLine("[#] AntiDebug Has Been Initialized.");
            }
            else { }
            //
            if (protection.AntiDump)
            {
                Protection.Dump.Initialize();
                Console.WriteLine("[#] AntiDump Has Been Initialized.");
            }
            else { }
            //
            if (protection.AntiProcess)
            {
                Protection.ProcessCheck.Initialize();
                Console.WriteLine("[#] AntiProcess Has Been Initialized.");
            }
            else 
            { 

            }
            
            var language = ConfigurationManager.AppSettings["language"];
            Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo(language);
            Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo(language);
            Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo(language);

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Login());
        }
    }
}
